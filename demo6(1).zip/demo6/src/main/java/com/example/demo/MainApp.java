package com.example.demo;

import io.minio.*;
import jakarta.annotation.PostConstruct;
import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@SpringBootApplication
@RestController
public class MainApp {

    MinioClient m = MinioClient.builder()
            .endpoint("http://localhost:9000")
            .credentials("admin", "password")
            .build();

    public static void main(String[] a) {
        SpringApplication.run(MainApp.class, a);
    }

    @PostConstruct
    void init() throws Exception {
        if (!m.bucketExists(BucketExistsArgs.builder().bucket("my-bucket").build()))
            m.makeBucket(MakeBucketArgs.builder().bucket("my-bucket").build());
    }

    @PostMapping("/upload")
    String up(@RequestParam MultipartFile f) throws Exception {
        m.putObject(PutObjectArgs.builder()
                .bucket("my-bucket")
                .object(f.getOriginalFilename())
                .stream(f.getInputStream(), f.getSize(), -1)
                .contentType(f.getContentType())
                .build());
        return " Загружен: " + f.getOriginalFilename();
    }

    @GetMapping("/download/{n}")
    ResponseEntity<byte[]> dl(@PathVariable String n) throws Exception {
        var s = m.getObject(GetObjectArgs.builder()
                .bucket("my-bucket")
                .object(n)
                .build());
        return ResponseEntity.ok()
                .header("Content-Disposition", "attachment; filename=" + n)
                .body(s.readAllBytes());
    }
}
